#include<lpc21xx.h>

int main()
{
	int a=5;
	int b=10;
	int c,d,e;
	c = a+b;
	d = a*b;
	e = b/a;
	return 0;
}
	